# API-HUB Agent 15min DashScope Business Test Review

## 1. Basic Info

- runId: manual_dashscope_15min_20260623-151937
- startTime: 2026-06-23 15:19:37
- endTime: 2026-06-23 15:36:26
- durationSeconds: 1009
- configuredTrafficDurationSeconds: 900
- BaseUrl: http://localhost:8080
- MockProviderBaseUrl: http://localhost:8090
- model: qwen-plus
- scenarioRunId: manual_dashscope_15min_20260623-151937
- FastMode: False
- DebugMode: False
- SkipDashScope: False
- SkipPromptSave: False

## 2. Business Timeline

See 01-business-timeline.md for Phase A-F design. The core overlap window is Phase C, where lecture registration peak and network/downstream fluctuation are active at the same time.

| Phase | Slug | OffsetSeconds | DurationSeconds | Expected Risk |
|---|---|---:|---:|---|
| Phase A: 日常低峰基线 | daily-baseline | 0-150 | 150 | NORMAL |
| Phase B: 讲座报名爬坡 | lecture-ramp-up | 150-300 | 150 | RISING |
| Phase C: 讲座报名高峰 + 网络波动交叉 | lecture-peak-network-overlap | 300-630 | 330 | WARNING |
| Phase D: 讲座报名回落 + 网络恢复 | lecture-ramp-down-network-recovery | 630-750 | 120 | RECOVERING |
| Phase E: 轻量认证异常穿插 | light-auth-anomaly | 750-840 | 90 | LOCAL_AUTH_EVIDENCE |
| Phase F: 恢复日常基线 | recovered-daily-baseline | 840-900 | 60 | NORMAL |

## 3. Traffic Summary

- totalRequests: 1926
- successCount: 1550
- failCount: 376
- statusCodeDistribution: 200=1550, 429=148, 409=118, 401=19, 504=80, 403=11
- apiDistribution: AUTH_LOGIN=256, COURSE_TODAY=244, CAMPUS_NOTICE=44, LECTURE_LIST=445, LIBRARY_BORROW=205, LECTURE_REGISTER=732
- phaseDistribution: Phase A=154, Phase B=295, Phase C=1068, Phase D=235, Phase E=112, Phase F=62
- mockScenarioDistribution: NORMAL=1530, RATE_LIMITED=148, DUPLICATE_REQUEST=75, HOT_READ=20, TOKEN_EXPIRED=19, COURSE_SYSTEM_TIMEOUT=45, SOLD_OUT=43, DOWNSTREAM_TIMEOUT=35, SIGNATURE_MISMATCH=11

## 4. Stats Aggregation Summary

- evaluatedWindows: 8
- successfulWindows: 8
- raw file: 04-stats-aggregator-responses.json

## 5. Alert Evaluation Summary

- evaluatedWindows: 8
- alertCount: 98
- raw file: 05-alert-evaluator-responses.json

## 6. Deterministic Reports

| reportName | reportId | apiCode | riskLevel | evidenceCount | toolTraceCount |
|---|---:|---|---|---:|---:|
| baseline | 16109 | COURSE_TODAY | NORMAL | 26 | 7 |
| lecture-main | 16110 | LECTURE_REGISTER | CRITICAL | 45 | 7 |
| lecture-overlap | 16111 | LECTURE_REGISTER | CRITICAL | 45 | 7 |
| network-course | 16112 | COURSE_TODAY | NORMAL | 26 | 7 |
| network-library | 16113 | LIBRARY_BORROW | NORMAL | 26 | 7 |
| auth | 16114 | AUTH_LOGIN | WARNING | 34 | 7 |
| recovery | 16115 | COURSE_TODAY | NORMAL | 22 | 7 |

## 7. DashScope Reports

| reportName | provider | model | fallbackUsed | validation.success | riskLevel | riskLevelChanged | recommendationCount | uncertaintyCount | latencyMs |
|---|---|---|---|---|---|---|---:|---:|---:|
| baseline | DASHSCOPE | qwen-plus | False | True | NORMAL | False | 1 | 1 | 8809 |
| lecture-main | DASHSCOPE | qwen-plus | False | True | CRITICAL | False | 3 | 1 | 19435 |
| lecture-overlap | DASHSCOPE | qwen-plus | False | True | CRITICAL | False | 3 | 2 | 27836 |
| network-course | DASHSCOPE | qwen-plus | False | True | NORMAL | False | 1 | 1 | 9506 |
| network-library | DASHSCOPE | qwen-plus | False | True | NORMAL | False | 2 | 0 | 12057 |
| auth | DASHSCOPE | qwen-plus | False | True | WARNING | False | 3 | 2 | 16207 |
| recovery | DASHSCOPE | qwen-plus | False | True | NORMAL | False | 1 | 1 | 8076 |

## 8. Key Observations

- Lecture peak recognition: check lecture-main and lecture-overlap risk levels and alert evidence.
- Network fluctuation recognition: check network-course and network-library for timeout/downstream evidence.
- Overlap explanation: check DashScope lecture-overlap output for phase C cross-window wording.
- Normal baseline noise: check baseline and recovery reports for NORMAL or documented deviations.
- Auth anomaly: check auth report for token/signature evidence.

## 9. LLM Output Quality Checklist

- riskLevel preserved: inspect each 08-dashscope-report-*.json.
- evidenceRefs present: inspect recommendations and evidenceUsage in each DashScope report.
- validation errors: see 10-validation-summary.json and per-report validation fields.
- simulation boundary: DashScope output must say this is development simulation, not production incident.
- unsupported alert fabrication: validator should catch HIGH_5XX / AUTH_FAILURE_SPIKE without evidence.
- Gateway local limiter fabrication: output should not claim Gateway local rate limiter fired unless evidence says so.

## 10. Failures And Gaps

- API request errors: 0, see 11-raw-api-errors.jsonl.
- DashScope fallback count: 0.
- Reports with insufficient evidence should be inspected in per-report JSON.
- If expected alerts are missing, tune phase C traffic weights or alert evaluator windows.

## 11. Recommendations

- Add LLM Eval Cases from this run's best and worst DashScope outputs.
- Add a frontend or HTML summary over these JSON artifacts.
- Consider a dedicated overlap scenario runner if repeated manual runs need stronger reproducibility.

Output directory: D:\tmp\apihub-agent-dashscope-15min-business-test\output\run-20260623-151937