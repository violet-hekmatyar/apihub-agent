param(
    [string]$BaseUrl = "http://localhost:8080",
    [string]$MockProviderBaseUrl = "http://localhost:8090",
    [int]$DurationSeconds = 900,
    [switch]$FastMode,
    [switch]$DebugMode,
    [int]$DebugDurationSeconds = 90,
    [switch]$SkipDashScope,
    [switch]$SkipPromptSave,
    [switch]$IncludePrompt,
    [int]$RandomSeed = 20260623,
    [string]$EnvFile = "D:\apihub-agent-dev\docker\.env"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$script:Utf8NoBom = [System.Text.UTF8Encoding]::new($false)
$BaseUrl = $BaseUrl.TrimEnd("/")
$MockProviderBaseUrl = $MockProviderBaseUrl.TrimEnd("/")
if ($DebugMode) {
    if ($DebugDurationSeconds -lt 30) {
        throw "DebugDurationSeconds must be at least 30 seconds."
    }
    $DurationSeconds = $DebugDurationSeconds
}
elseif ($FastMode) {
    $DurationSeconds = 240
}
if ($DurationSeconds -gt 1200) {
    throw "DurationSeconds must not exceed 1200 seconds."
}

$RunStamp = Get-Date -Format "yyyyMMdd-HHmmss"
$RootDir = "D:\tmp\apihub-agent-dashscope-15min-business-test"
$RunDir = Join-Path $RootDir "output\run-$RunStamp"
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null

$TrafficSamplesPath = Join-Path $RunDir "02-traffic-samples.jsonl"
$RawErrorsPath = Join-Path $RunDir "11-raw-api-errors.jsonl"
$StatsResponsesPath = Join-Path $RunDir "04-stats-aggregator-responses.json"
$AlertResponsesPath = Join-Path $RunDir "05-alert-evaluator-responses.json"
$ReportIndexPath = Join-Path $RunDir "06-agent-diagnosis-report-index.json"
$ValidationSummaryPath = Join-Path $RunDir "10-validation-summary.json"
$FinalReviewPath = Join-Path $RunDir "17-final-review.md"
New-Item -ItemType File -Force -Path $RawErrorsPath | Out-Null

$script:Random = [System.Random]::new($RandomSeed)
$script:Sequence = 0
$script:TrafficSamples = New-Object System.Collections.ArrayList
$script:ApiErrors = New-Object System.Collections.ArrayList
$script:StatsResponses = New-Object System.Collections.ArrayList
$script:AlertResponses = New-Object System.Collections.ArrayList
$script:ReportIndex = New-Object System.Collections.ArrayList
$script:DashScopeReports = New-Object System.Collections.ArrayList
$script:RunStartedAt = Get-Date
$script:ScenarioRunId = "manual_dashscope_15min_$RunStamp"
$script:CurrentPhaseCode = $null
$script:CurrentPhaseSlug = $null
$script:CurrentElapsedSecond = 0

function Convert-ErrorResponseToJson {
    param($Response)
    $stream = $Response.GetResponseStream()
    if ($null -eq $stream) { return $null }
    $reader = New-Object System.IO.StreamReader($stream)
    $content = $reader.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($content)) { return $null }
    return $content | ConvertFrom-Json
}

function Invoke-Json {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [hashtable]$Headers = @{},
        [string]$Body = $null,
        [int]$TimeoutSec = 30
    )
    $started = Get-Date
    $params = @{ Uri = $Url; Method = $Method; Headers = $Headers; TimeoutSec = $TimeoutSec }
    if (-not [string]::IsNullOrEmpty($Body)) {
        $params.ContentType = "application/json"
        $params.Body = $Body
    }
    try {
        $response = Invoke-RestMethod @params
        return [ordered]@{
            ok = $true
            response = $response
            latencyMs = [int]((Get-Date) - $started).TotalMilliseconds
            error = $null
        }
    }
    catch {
        $json = $null
        if ($_.Exception.Response) {
            $json = Convert-ErrorResponseToJson -Response $_.Exception.Response
        }
        return [ordered]@{
            ok = $false
            response = $json
            latencyMs = [int]((Get-Date) - $started).TotalMilliseconds
            error = $_.Exception.Message
        }
    }
}

function Write-Utf8Text {
    param([string]$Path, [string]$Content)
    [System.IO.File]::WriteAllText($Path, $Content, $script:Utf8NoBom)
}

function Save-Json {
    param([string]$Path, $Value)
    Write-Utf8Text -Path $Path -Content ($Value | ConvertTo-Json -Depth 40)
}

function Add-JsonLine {
    param([string]$Path, $Value)
    [System.IO.File]::AppendAllText($Path, (($Value | ConvertTo-Json -Depth 30 -Compress) + [Environment]::NewLine), $script:Utf8NoBom)
}

function Write-ScriptError {
    param(
        [Parameter(Mandatory = $true)]$ErrorRecord,
        [string]$Stage = "unknown"
    )
    $record = [ordered]@{
        timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
        stage = $Stage
        message = $ErrorRecord.Exception.Message
        exceptionType = $ErrorRecord.Exception.GetType().FullName
        positionMessage = $ErrorRecord.InvocationInfo.PositionMessage
        scriptStackTrace = $ErrorRecord.ScriptStackTrace
        runDir = $RunDir
        phaseCode = $script:CurrentPhaseCode
        phaseSlug = $script:CurrentPhaseSlug
        elapsedSecond = $script:CurrentElapsedSecond
        requestCount = $script:Sequence
    }
    Save-Json -Path (Join-Path $RunDir "99-script-error.json") -Value $record
    Add-JsonLine -Path $RawErrorsPath -Value $record
    return $record
}

function Load-EnvFile {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "env file not found: $Path"
    }
    Get-Content -LiteralPath $Path | ForEach-Object {
        $line = $_.Trim()
        if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith("#") -or -not $line.Contains("=")) {
            return
        }
        $idx = $line.IndexOf("=")
        $name = $line.Substring(0, $idx).Trim()
        $value = $line.Substring($idx + 1).Trim()
        if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        if (-not [string]::IsNullOrWhiteSpace($name)) {
            [Environment]::SetEnvironmentVariable($name, $value, "Process")
        }
    }
    if ([string]::IsNullOrWhiteSpace($env:DASHSCOPE_API_KEY)) {
        throw "DASHSCOPE_API_KEY is missing. Check $Path."
    }
    if ([string]::IsNullOrWhiteSpace($env:AI_BASE_URL)) {
        [Environment]::SetEnvironmentVariable("AI_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1", "Process")
    }
    if ([string]::IsNullOrWhiteSpace($env:AI_CHAT_MODEL)) {
        [Environment]::SetEnvironmentVariable("AI_CHAT_MODEL", "qwen-plus", "Process")
    }
}

function New-TraceId {
    return ([guid]::NewGuid().ToString("N"))
}

function Decode-Utf8 {
    param([string]$Base64)
    return [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Base64))
}

function Select-WeightedItem {
    param([array]$Items)
    $total = 0
    foreach ($item in $Items) { $total += [int]$item.weight }
    $roll = $script:Random.Next(1, $total + 1)
    $sum = 0
    foreach ($item in $Items) {
        $sum += [int]$item.weight
        if ($roll -le $sum) { return $item }
    }
    return $Items[-1]
}

function Get-AppCode {
    param([string]$ApiCode)
    switch ($ApiCode) {
        "AUTH_LOGIN" { "COURSE_HELPER"; break }
        "COURSE_TODAY" { "COURSE_HELPER"; break }
        "LECTURE_LIST" { "LECTURE_PORTAL"; break }
        "LECTURE_REGISTER" { "LECTURE_PORTAL"; break }
        "CAMPUS_NOTICE" { "STUDENT_SERVICE"; break }
        "LIBRARY_BORROW" { "LIBRARY_MINI"; break }
        default { "COURSE_HELPER" }
    }
}

function Get-PhaseChoices {
    param([string]$PhaseCode, [double]$LocalRatio)
    switch ($PhaseCode) {
        "Phase A" {
            return @{
                targetRps = 1.2
                choices = @(
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "COURSE_TODAY"; weight = 25; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "CAMPUS_NOTICE"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "LIBRARY_BORROW"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) }
                )
            }
        }
        "Phase B" {
            return @{
                targetRps = 1.5 + (2.5 * $LocalRatio)
                choices = @(
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 95 }, [ordered]@{ name = "TOKEN_EXPIRED"; weight = 3 }, [ordered]@{ name = "SIGNATURE_MISMATCH"; weight = 2 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 45; scenarios = @([ordered]@{ name = "NORMAL"; weight = 96 }, [ordered]@{ name = "HOT_READ"; weight = 4 }) },
                    [ordered]@{ apiCode = "LECTURE_REGISTER"; weight = 40; scenarios = @([ordered]@{ name = "NORMAL"; weight = 86 }, [ordered]@{ name = "DUPLICATE_REQUEST"; weight = 8 }, [ordered]@{ name = "RATE_LIMITED"; weight = 6 }) }
                )
            }
        }
        "Phase C" {
            return @{
                targetRps = if ($FastMode -or $DebugMode) { 4.0 } else { 6.0 }
                choices = @(
                    [ordered]@{ apiCode = "LECTURE_REGISTER"; weight = 48; scenarios = @([ordered]@{ name = "NORMAL"; weight = 55 }, [ordered]@{ name = "RATE_LIMITED"; weight = 25 }, [ordered]@{ name = "DUPLICATE_REQUEST"; weight = 12 }, [ordered]@{ name = "SOLD_OUT"; weight = 8 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 18; scenarios = @([ordered]@{ name = "NORMAL"; weight = 95 }, [ordered]@{ name = "HOT_READ"; weight = 5 }) },
                    [ordered]@{ apiCode = "COURSE_TODAY"; weight = 12; scenarios = @([ordered]@{ name = "NORMAL"; weight = 75 }, [ordered]@{ name = "COURSE_SYSTEM_TIMEOUT"; weight = 25 }) },
                    [ordered]@{ apiCode = "LIBRARY_BORROW"; weight = 12; scenarios = @([ordered]@{ name = "NORMAL"; weight = 75 }, [ordered]@{ name = "DOWNSTREAM_TIMEOUT"; weight = 25 }) },
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 10; scenarios = @([ordered]@{ name = "NORMAL"; weight = 97 }, [ordered]@{ name = "TOKEN_EXPIRED"; weight = 3 }) }
                )
            }
        }
        "Phase D" {
            return @{
                targetRps = 4.0 - (2.5 * $LocalRatio)
                choices = @(
                    [ordered]@{ apiCode = "LECTURE_REGISTER"; weight = 42; scenarios = @([ordered]@{ name = "NORMAL"; weight = 75 }, [ordered]@{ name = "RATE_LIMITED"; weight = 12 }, [ordered]@{ name = "DUPLICATE_REQUEST"; weight = 8 }, [ordered]@{ name = "SOLD_OUT"; weight = 5 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 98 }, [ordered]@{ name = "HOT_READ"; weight = 2 }) },
                    [ordered]@{ apiCode = "COURSE_TODAY"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 90 }, [ordered]@{ name = "COURSE_SYSTEM_TIMEOUT"; weight = 10 }) },
                    [ordered]@{ apiCode = "LIBRARY_BORROW"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 90 }, [ordered]@{ name = "DOWNSTREAM_TIMEOUT"; weight = 10 }) },
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 8; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) }
                )
            }
        }
        "Phase E" {
            return @{
                targetRps = 1.5
                choices = @(
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 70; scenarios = @([ordered]@{ name = "NORMAL"; weight = 65 }, [ordered]@{ name = "TOKEN_EXPIRED"; weight = 20 }, [ordered]@{ name = "SIGNATURE_MISMATCH"; weight = 15 }) },
                    [ordered]@{ apiCode = "COURSE_TODAY"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) }
                )
            }
        }
        default {
            return @{
                targetRps = 1.2
                choices = @(
                    [ordered]@{ apiCode = "AUTH_LOGIN"; weight = 15; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "COURSE_TODAY"; weight = 25; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "LECTURE_LIST"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "CAMPUS_NOTICE"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) },
                    [ordered]@{ apiCode = "LIBRARY_BORROW"; weight = 20; scenarios = @([ordered]@{ name = "NORMAL"; weight = 100 }) }
                )
            }
        }
    }
}

function Get-PhasePlan {
    param([int]$DurationSeconds)
    $definitions = @(
        [ordered]@{ phaseCode = "Phase A"; phaseSlug = "daily-baseline"; phaseName = (Decode-Utf8 "5pel5bi45L2O5bOw5Z+657q/"); baseDurationSec = 150; businessMeaning = "Daily low-traffic baseline."; expectedRisk = "NORMAL" },
        [ordered]@{ phaseCode = "Phase B"; phaseSlug = "lecture-ramp-up"; phaseName = (Decode-Utf8 "6K6y5bqn5oql5ZCN54is5Z2h"); baseDurationSec = 150; businessMeaning = "Lecture signup traffic ramps up before opening."; expectedRisk = "RISING" },
        [ordered]@{ phaseCode = "Phase C"; phaseSlug = "lecture-peak-network-overlap"; phaseName = (Decode-Utf8 "6K6y5bqn5oql5ZCN6auY5bOwICsg572R57uc5rOi5Yqo5Lqk5Y+J"); baseDurationSec = 330; businessMeaning = "Lecture signup peak overlaps with network/downstream fluctuation."; expectedRisk = "WARNING" },
        [ordered]@{ phaseCode = "Phase D"; phaseSlug = "lecture-ramp-down-network-recovery"; phaseName = (Decode-Utf8 "6K6y5bqn5oql5ZCN5Zue6JC9ICsg572R57uc5oGi5aSN"); baseDurationSec = 120; businessMeaning = "Lecture peak and network fluctuation taper down."; expectedRisk = "RECOVERING" },
        [ordered]@{ phaseCode = "Phase E"; phaseSlug = "light-auth-anomaly"; phaseName = (Decode-Utf8 "6L276YeP6K6k6K+B5byC5bi456m/5o+S"); baseDurationSec = 90; businessMeaning = "Light authentication anomaly is injected for local evidence."; expectedRisk = "LOCAL_AUTH_EVIDENCE" },
        [ordered]@{ phaseCode = "Phase F"; phaseSlug = "recovered-daily-baseline"; phaseName = (Decode-Utf8 "5oGi5aSN5pel5bi45Z+657q/"); baseDurationSec = 60; businessMeaning = "Traffic returns to a daily baseline."; expectedRisk = "NORMAL" }
    )
    $plan = New-Object System.Collections.ArrayList
    $cursor = 0
    $baseCursor = 0
    for ($i = 0; $i -lt $definitions.Count; $i++) {
        $def = $definitions[$i]
        $start = $cursor
        $baseCursor += [int]$def.baseDurationSec
        if ($i -eq ($definitions.Count - 1)) {
            $end = $DurationSeconds
        }
        else {
            $end = [int][Math]::Round([double]$baseCursor * ([double]$DurationSeconds / 900.0))
        }
        if ($end -le $start) { $end = $start + 1 }
        $cursor = $end
        $shape = Get-PhaseChoices -PhaseCode $def.phaseCode -LocalRatio 0.0
        [void]$plan.Add([pscustomobject]([ordered]@{
            phaseCode = $def.phaseCode
            phaseSlug = $def.phaseSlug
            phaseName = $def.phaseName
            phaseLabel = "$($def.phaseCode): $($def.phaseName)"
            key = $def.phaseCode
            name = $def.phaseSlug
            startOffsetSec = $start
            endOffsetSec = $end
            durationSec = $end - $start
            businessMeaning = $def.businessMeaning
            expectedRisk = $def.expectedRisk
            targetRps = [double]$shape.targetRps
            choices = $shape.choices
        }))
    }
    return @($plan)
}

function Get-CurrentPhase {
    param([int]$ElapsedSecond, [array]$PhasePlan)
    foreach ($phase in $PhasePlan) {
        if ($ElapsedSecond -ge $phase.startOffsetSec -and $ElapsedSecond -lt $phase.endOffsetSec) {
            $duration = [Math]::Max(1, [int]$phase.durationSec)
            $local = [Math]::Min(1.0, [Math]::Max(0.0, ([double]($ElapsedSecond - $phase.startOffsetSec) / [double]$duration)))
            $shape = Get-PhaseChoices -PhaseCode $phase.phaseCode -LocalRatio $local
            $phase.targetRps = [double]$shape.targetRps
            $phase.choices = $shape.choices
            return $phase
        }
    }
    return $PhasePlan[-1]
}

function Invoke-GatewayCall {
    param([int]$ElapsedSecond, [object]$Phase)
    $script:Sequence++
    $apiChoice = Select-WeightedItem -Items $Phase.choices
    $scenarioChoice = Select-WeightedItem -Items $apiChoice.scenarios
    $apiCode = $apiChoice.apiCode
    $mockScenario = $scenarioChoice.name
    $appCode = Get-AppCode -ApiCode $apiCode
    $requestId = "req_${script:ScenarioRunId}_$($script:Sequence)"
    $traceId = New-TraceId
    $body = [ordered]@{
        apiCode = $apiCode
        appCode = $appCode
        mockScenario = $mockScenario
        timeoutMs = 5000
        clientInfo = [ordered]@{
            clientIp = "10.42.$(($script:Sequence % 200) + 1).$(($script:Random.Next(1, 240)))"
            userAgent = "apihub-dashscope-15min-business-test/1.0"
        }
        scenarioContext = [ordered]@{
            scenarioRunId = $script:ScenarioRunId
            scenarioId = "DASHSCOPE_15MIN_BUSINESS_TEST"
            scenarioKey = $Phase.phaseSlug
            phase = $Phase.phaseCode
            phaseCode = $Phase.phaseCode
            phaseSlug = $Phase.phaseSlug
            phaseName = $Phase.phaseName
            sequenceNo = $script:Sequence
        }
        queryParams = [ordered]@{
            studentId = "stu_$($script:Sequence)"
            noticeId = "notice_$($script:Sequence)"
            bookId = "book_$($script:Sequence)"
        }
        body = [ordered]@{
            requestNo = $requestId
            businessPhase = $Phase.phaseLabel
        }
    } | ConvertTo-Json -Depth 12 -Compress

    $result = Invoke-Json -Method "POST" -Url "$BaseUrl/api/dev/gateway/invoke" -Headers @{ "X-Request-Id" = $requestId; "X-Trace-Id" = $traceId } -Body $body -TimeoutSec 15
    $data = $result.response.data
    $record = [ordered]@{
        timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
        elapsedSecond = $ElapsedSecond
        phase = $Phase.phaseCode
        phaseCode = $Phase.phaseCode
        phaseSlug = $Phase.phaseSlug
        phaseName = $Phase.phaseName
        phaseLabel = $Phase.phaseLabel
        scenarioName = $Phase.businessMeaning
        apiCode = $apiCode
        appCode = $appCode
        mockScenario = $mockScenario
        expectedBusinessMeaning = $Phase.expectedRisk
        httpStatus = if ($data) { $data.upstreamStatus } else { $null }
        businessCode = if ($data) { $data.upstreamCode } else { $null }
        latencyMs = if ($data) { $data.latencyMs } else { $result.latencyMs }
        traceId = if ($data) { $data.traceId } else { $traceId }
        requestId = if ($data) { $data.requestId } else { $requestId }
        success = if ($data) { $data.success } else { $false }
        errorMessage = if ($result.ok) { $null } else { $result.error }
        gatewayLogId = if ($data) { $data.gatewayLogId } else { $null }
    }
    [void]$script:TrafficSamples.Add([pscustomobject]$record)
    Add-JsonLine -Path $TrafficSamplesPath -Value $record
    if (-not $result.ok) {
        [void]$script:ApiErrors.Add([pscustomobject]$record)
        Add-JsonLine -Path $RawErrorsPath -Value $record
    }
}

function Run-Traffic {
    Write-Host "Running business traffic for $DurationSeconds seconds. scenarioRunId=$script:ScenarioRunId"
    $phasePlan = Get-PhasePlan -DurationSeconds $DurationSeconds
    $start = Get-Date
    $nextProgress = 0
    while ($true) {
        $elapsed = [int]((Get-Date) - $start).TotalSeconds
        if ($elapsed -ge $DurationSeconds) { break }
        $phase = Get-CurrentPhase -ElapsedSecond $elapsed -PhasePlan $phasePlan
        $script:CurrentPhaseCode = $phase.phaseCode
        $script:CurrentPhaseSlug = $phase.phaseSlug
        $script:CurrentElapsedSecond = $elapsed
        $targetRps = [double]$phase.targetRps
        $calls = [Math]::Max(1, [Math]::Round($targetRps))
        for ($i = 0; $i -lt $calls; $i++) {
            Invoke-GatewayCall -ElapsedSecond $elapsed -Phase $phase
            $sleepMs = [Math]::Max(80, [int](1000 / [Math]::Max(1.0, $targetRps)))
            Start-Sleep -Milliseconds $sleepMs
        }
        if ($elapsed -ge $nextProgress) {
            Write-Host ("  elapsed={0}s phase={1} slug={2} requests={3}" -f $elapsed, $phase.phaseLabel, $phase.phaseSlug, $script:TrafficSamples.Count)
            $nextProgress += 60
        }
    }
}

function Get-WindowSpecs {
    param([datetime]$Start)
    $scale = [double]$DurationSeconds / 900.0
    return @(
        [ordered]@{ name = "full"; apiCode = $null; start = 0; end = 900; purpose = "Full business test window" },
        [ordered]@{ name = "lecture-main"; apiCode = "LECTURE_REGISTER"; start = 150; end = 750; purpose = "Lecture signup main risk" },
        [ordered]@{ name = "lecture-overlap"; apiCode = "LECTURE_REGISTER"; start = 300; end = 630; purpose = "Lecture/network overlap window" },
        [ordered]@{ name = "network-course"; apiCode = "COURSE_TODAY"; start = 300; end = 630; purpose = "Course service network fluctuation" },
        [ordered]@{ name = "network-library"; apiCode = "LIBRARY_BORROW"; start = 300; end = 630; purpose = "Library downstream fluctuation" },
        [ordered]@{ name = "auth"; apiCode = "AUTH_LOGIN"; start = 750; end = 840; purpose = "Authentication anomaly" },
        [ordered]@{ name = "recovery"; apiCode = $null; start = 840; end = 900; purpose = "Recovered baseline" },
        [ordered]@{ name = "baseline"; apiCode = "COURSE_TODAY"; start = 0; end = 150; purpose = "Daily normal baseline" }
    ) | ForEach-Object {
        $s = $Start.AddSeconds([int]([double]$_.start * $scale) - 10)
        $e = $Start.AddSeconds([int]([double]$_.end * $scale) + 10)
        [ordered]@{
            name = $_.name
            apiCode = $_.apiCode
            startTime = $s.ToString("yyyy-MM-dd HH:mm:ss")
            endTime = $e.ToString("yyyy-MM-dd HH:mm:ss")
            purpose = $_.purpose
        }
    }
}

function Invoke-StatsAggregate {
    param([array]$Windows)
    foreach ($window in $Windows) {
        $body = [ordered]@{
            startTime = $window.startTime
            endTime = $window.endTime
            scenarioRunId = $script:ScenarioRunId
            apiCode = $window.apiCode
            forceRebuild = $true
        } | ConvertTo-Json -Depth 10 -Compress
        $result = Invoke-Json -Method "POST" -Url "$BaseUrl/api/dev/stats/aggregate" -Body $body -TimeoutSec 60
        $record = [ordered]@{ window = $window; ok = $result.ok; latencyMs = $result.latencyMs; response = $result.response; error = $result.error }
        [void]$script:StatsResponses.Add([pscustomobject]$record)
        Write-Host "Stats aggregate window=$($window.name) api=$($window.apiCode) ok=$($result.ok)"
    }
    Save-Json -Path $StatsResponsesPath -Value $script:StatsResponses
}

function Invoke-AlertEvaluate {
    param([array]$Windows)
    foreach ($window in $Windows) {
        $body = [ordered]@{
            startTime = $window.startTime
            endTime = $window.endTime
            scenarioRunId = $script:ScenarioRunId
            apiCode = $window.apiCode
            mode = "DEV_SHORT_WINDOW"
            windowSeconds = 30
            forceRebuild = $true
        } | ConvertTo-Json -Depth 10 -Compress
        $result = Invoke-Json -Method "POST" -Url "$BaseUrl/api/dev/alerts/evaluate" -Body $body -TimeoutSec 60
        $record = [ordered]@{ window = $window; ok = $result.ok; latencyMs = $result.latencyMs; response = $result.response; error = $result.error }
        [void]$script:AlertResponses.Add([pscustomobject]$record)
        Write-Host "Alert evaluate window=$($window.name) api=$($window.apiCode) ok=$($result.ok)"
    }
    Save-Json -Path $AlertResponsesPath -Value $script:AlertResponses
}

function Invoke-AgentDiagnose {
    param([array]$Windows)
    $reportSpecs = @(
        [ordered]@{ reportName = "baseline"; apiCode = "COURSE_TODAY"; windowName = "baseline" },
        [ordered]@{ reportName = "lecture-main"; apiCode = "LECTURE_REGISTER"; windowName = "lecture-main" },
        [ordered]@{ reportName = "lecture-overlap"; apiCode = "LECTURE_REGISTER"; windowName = "lecture-overlap" },
        [ordered]@{ reportName = "network-course"; apiCode = "COURSE_TODAY"; windowName = "network-course" },
        [ordered]@{ reportName = "network-library"; apiCode = "LIBRARY_BORROW"; windowName = "network-library" },
        [ordered]@{ reportName = "auth"; apiCode = "AUTH_LOGIN"; windowName = "auth" },
        [ordered]@{ reportName = "recovery"; apiCode = "COURSE_TODAY"; windowName = "recovery" }
    )
    foreach ($spec in $reportSpecs) {
        $window = @($Windows | Where-Object { $_.name -eq $spec.windowName })[0]
        $body = [ordered]@{
            apiCode = $spec.apiCode
            startTime = $window.startTime
            endTime = $window.endTime
            scenarioRunId = $script:ScenarioRunId
            diagnosisMode = "DETERMINISTIC"
            forceRebuild = $true
        } | ConvertTo-Json -Depth 10 -Compress
        $result = Invoke-Json -Method "POST" -Url "$BaseUrl/api/dev/agent/diagnose" -Headers @{ "X-Demo-User-Id" = "1" } -Body $body -TimeoutSec 60
        $reportId = if ($result.response -and $result.response.data) { $result.response.data.reportId } else { $null }
        $record = [ordered]@{
            reportName = $spec.reportName
            apiCode = $spec.apiCode
            window = $window
            ok = $result.ok
            reportId = $reportId
            riskLevel = if ($result.response -and $result.response.data) { $result.response.data.riskLevel } else { $null }
            evidenceCount = if ($result.response -and $result.response.data) { $result.response.data.evidenceCount } else { $null }
            toolTraceCount = if ($result.response -and $result.response.data) { $result.response.data.toolCallCount } else { $null }
            response = $result.response
            error = $result.error
        }
        [void]$script:ReportIndex.Add([pscustomobject]$record)
        Save-Json -Path (Join-Path $RunDir "07-deterministic-report-$($spec.reportName).json") -Value $record
        Write-Host "Agent diagnose report=$($spec.reportName) reportId=$reportId risk=$($record.riskLevel)"
    }
    Save-Json -Path $ReportIndexPath -Value $script:ReportIndex
}

function Invoke-DashScopeDiagnosis {
    foreach ($report in $script:ReportIndex) {
        if (-not $report.reportId) { continue }
        $body = [ordered]@{
            reportId = [int64]$report.reportId
            includePrompt = [bool]$IncludePrompt
        } | ConvertTo-Json -Depth 10 -Compress
        $result = Invoke-Json -Method "POST" -Url "$BaseUrl/api/dev/agent/diagnose/llm/dashscope" -Body $body -TimeoutSec 120
        $data = if ($result.response) { $result.response.data } else { $null }
        $record = [ordered]@{
            reportName = $report.reportName
            reportId = $report.reportId
            ok = $result.ok
            provider = if ($data) { $data.provider } else { $null }
            model = if ($data) { $data.model } else { $env:AI_CHAT_MODEL }
            fallbackUsed = if ($data) { $data.fallbackUsed } else { $null }
            fallbackReason = if ($data) { $data.fallbackReason } else { $null }
            validationSuccess = if ($data -and $data.validation) { $data.validation.success } else { $null }
            riskLevel = if ($data -and $data.output) { $data.output.riskLevel } else { $null }
            riskLevelChanged = if ($data -and $data.output) { $data.output.riskLevelChanged } else { $null }
            recommendationCount = if ($data -and $data.output -and $data.output.recommendations) { @($data.output.recommendations).Count } else { 0 }
            uncertaintyCount = if ($data -and $data.output -and $data.output.uncertainties) { @($data.output.uncertainties).Count } else { 0 }
            latencyMs = if ($data) { $data.latencyMs } else { $result.latencyMs }
            validationErrors = if ($data -and $data.validation) { $data.validation.errors } else { @() }
            response = $result.response
            error = $result.error
        }
        $jsonText = $record | ConvertTo-Json -Depth 50 -Compress
        if (-not [string]::IsNullOrWhiteSpace($env:DASHSCOPE_API_KEY) -and $jsonText.Contains($env:DASHSCOPE_API_KEY)) {
            $record.fallbackUsed = $true
            $record.fallbackReason = "API_KEY_LEAK_DETECTED_IN_LOCAL_RESPONSE_OBJECT"
            $record.response = $null
        }
        Save-Json -Path (Join-Path $RunDir "08-dashscope-report-$($report.reportName).json") -Value $record
        if (-not $SkipPromptSave -and $data -and $data.prompt) {
            $prompt = [ordered]@{
                systemPrompt = $data.prompt.systemPrompt
                diagnosisPrompt = $data.prompt.diagnosisPrompt
                inputJson = $data.prompt.inputJson
                schemaJson = $data.prompt.outputSchemaJson
            }
            Save-Json -Path (Join-Path $RunDir "09-prompt-$($report.reportName).json") -Value $prompt
        }
        [void]$script:DashScopeReports.Add([pscustomobject]$record)
        Write-Host "DashScope report=$($report.reportName) fallback=$($record.fallbackUsed) validation=$($record.validationSuccess)"
    }
}

function Build-TrafficSummary {
    $samples = @($script:TrafficSamples)
    $statusDist = $samples | Group-Object httpStatus | ForEach-Object { [ordered]@{ name = "$($_.Name)"; count = $_.Count } }
    $apiDist = $samples | Group-Object apiCode | ForEach-Object { [ordered]@{ name = $_.Name; count = $_.Count } }
    $phaseDist = $samples | Group-Object phaseCode | ForEach-Object { [ordered]@{ name = $_.Name; count = $_.Count } }
    $scenarioDist = $samples | Group-Object mockScenario | ForEach-Object { [ordered]@{ name = $_.Name; count = $_.Count } }
    $summary = [ordered]@{
        totalRequests = $samples.Count
        successCount = @($samples | Where-Object { $_.success -eq $true }).Count
        failCount = @($samples | Where-Object { $_.success -ne $true }).Count
        statusCodeDistribution = $statusDist
        apiDistribution = $apiDist
        phaseDistribution = $phaseDist
        mockScenarioDistribution = $scenarioDist
    }
    Save-Json -Path (Join-Path $RunDir "03-traffic-summary.json") -Value $summary
    return $summary
}

function Write-TestPlan {
    $phasePlan = Get-PhasePlan -DurationSeconds $DurationSeconds
    $phaseRows = ($phasePlan | ForEach-Object {
        $start = [TimeSpan]::FromSeconds([int]$_.startOffsetSec)
        $end = [TimeSpan]::FromSeconds([int]$_.endOffsetSec)
        $startText = $start.ToString("mm\:ss")
        $endText = $end.ToString("mm\:ss")
        "| $($_.phaseLabel) | $startText-$endText | $($_.phaseSlug) | $($_.businessMeaning) | $($_.expectedRisk) |"
    }) -join "`n"
    $plan = [ordered]@{
        runId = $script:ScenarioRunId
        durationSeconds = $DurationSeconds
        fastMode = [bool]$FastMode
        debugMode = [bool]$DebugMode
        skipDashScope = [bool]$SkipDashScope
        skipPromptSave = [bool]$SkipPromptSave
        randomSeed = $RandomSeed
        baseUrl = $BaseUrl
        mockProviderBaseUrl = $MockProviderBaseUrl
        phases = $phasePlan
    }
    Save-Json -Path (Join-Path $RunDir "00-test-plan.json") -Value $plan
    @"
# API-HUB Agent 15min DashScope Business Test Timeline

RunId: $script:ScenarioRunId
DurationSeconds: $DurationSeconds

| Phase | Relative Time | Slug | Business Meaning | Expected Risk |
|---|---|---|---|---|
$phaseRows

All traffic is sent through POST /api/dev/gateway/invoke. No database writes are performed directly by this script.
"@ | ForEach-Object { Write-Utf8Text -Path (Join-Path $RunDir "01-business-timeline.md") -Content $_ }
}

function Write-FinalReview {
    param([object]$TrafficSummary, [array]$Windows)
    $statsOk = @($script:StatsResponses | Where-Object { $_.ok }).Count
    $alertCount = 0
    foreach ($alert in $script:AlertResponses) {
        if ($alert.response -and $alert.response.data) {
            $alertCount += [int]$alert.response.data.createdAlertCount + [int]$alert.response.data.updatedAlertCount
        }
    }
    $dashValidationSuccess = @($script:DashScopeReports | Where-Object { $_.validationSuccess -eq $true }).Count
    $dashFallback = @($script:DashScopeReports | Where-Object { $_.fallbackUsed -eq $true }).Count
    $validation = [ordered]@{
        deterministicReportAttempts = @($script:ReportIndex).Count
        deterministicReportSuccess = @($script:ReportIndex | Where-Object { $_.reportId }).Count
        dashScopeReportAttempts = @($script:DashScopeReports).Count
        dashScopeValidationSuccess = $dashValidationSuccess
        dashScopeFallbackCount = $dashFallback
        statsWindowSuccess = $statsOk
        alertCount = $alertCount
    }
    Save-Json -Path $ValidationSummaryPath -Value $validation

    $reportRows = ($script:ReportIndex | ForEach-Object {
        "| $($_.reportName) | $($_.reportId) | $($_.apiCode) | $($_.riskLevel) | $($_.evidenceCount) | $($_.toolTraceCount) |"
    }) -join "`n"
    $dashRows = ($script:DashScopeReports | ForEach-Object {
        "| $($_.reportName) | $($_.provider) | $($_.model) | $($_.fallbackUsed) | $($_.validationSuccess) | $($_.riskLevel) | $($_.riskLevelChanged) | $($_.recommendationCount) | $($_.uncertaintyCount) | $($_.latencyMs) |"
    }) -join "`n"
    $statusDistText = (($TrafficSummary.statusCodeDistribution | ForEach-Object { "$($_.name)=$($_.count)" }) -join ", ")
    $apiDistText = (($TrafficSummary.apiDistribution | ForEach-Object { "$($_.name)=$($_.count)" }) -join ", ")
    $phaseDistText = (($TrafficSummary.phaseDistribution | ForEach-Object { "$($_.name)=$($_.count)" }) -join ", ")
    $scenarioDistText = (($TrafficSummary.mockScenarioDistribution | ForEach-Object { "$($_.name)=$($_.count)" }) -join ", ")
    $phasePlan = Get-PhasePlan -DurationSeconds $DurationSeconds
    $phasePlanRows = ($phasePlan | ForEach-Object {
        "| $($_.phaseLabel) | $($_.phaseSlug) | $($_.startOffsetSec)-$($_.endOffsetSec) | $($_.durationSec) | $($_.expectedRisk) |"
    }) -join "`n"
    $runEndedAt = Get-Date
    $actualDuration = [int]($runEndedAt - $script:RunStartedAt).TotalSeconds

@"
# API-HUB Agent 15min DashScope Business Test Review

## 1. Basic Info

- runId: $script:ScenarioRunId
- startTime: $($script:RunStartedAt.ToString("yyyy-MM-dd HH:mm:ss"))
- endTime: $($runEndedAt.ToString("yyyy-MM-dd HH:mm:ss"))
- durationSeconds: $actualDuration
- configuredTrafficDurationSeconds: $DurationSeconds
- BaseUrl: $BaseUrl
- MockProviderBaseUrl: $MockProviderBaseUrl
- model: $env:AI_CHAT_MODEL
- scenarioRunId: $script:ScenarioRunId
- FastMode: $FastMode
- DebugMode: $DebugMode
- SkipDashScope: $SkipDashScope
- SkipPromptSave: $SkipPromptSave

## 2. Business Timeline

See 01-business-timeline.md for Phase A-F design. The core overlap window is Phase C, where lecture registration peak and network/downstream fluctuation are active at the same time.

| Phase | Slug | OffsetSeconds | DurationSeconds | Expected Risk |
|---|---|---:|---:|---|
$phasePlanRows

## 3. Traffic Summary

- totalRequests: $($TrafficSummary.totalRequests)
- successCount: $($TrafficSummary.successCount)
- failCount: $($TrafficSummary.failCount)
- statusCodeDistribution: $statusDistText
- apiDistribution: $apiDistText
- phaseDistribution: $phaseDistText
- mockScenarioDistribution: $scenarioDistText

## 4. Stats Aggregation Summary

- evaluatedWindows: $(@($script:StatsResponses).Count)
- successfulWindows: $statsOk
- raw file: 04-stats-aggregator-responses.json

## 5. Alert Evaluation Summary

- evaluatedWindows: $(@($script:AlertResponses).Count)
- alertCount: $alertCount
- raw file: 05-alert-evaluator-responses.json

## 6. Deterministic Reports

| reportName | reportId | apiCode | riskLevel | evidenceCount | toolTraceCount |
|---|---:|---|---|---:|---:|
$reportRows

## 7. DashScope Reports

| reportName | provider | model | fallbackUsed | validation.success | riskLevel | riskLevelChanged | recommendationCount | uncertaintyCount | latencyMs |
|---|---|---|---|---|---|---|---:|---:|---:|
$dashRows

## 8. Key Observations

- Lecture peak recognition: check lecture-main and lecture-overlap risk levels and alert evidence.
- Network fluctuation recognition: check network-course and network-library for timeout/downstream evidence.
- Overlap explanation: check DashScope lecture-overlap output for phase C cross-window wording.
- Normal baseline noise: check baseline and recovery reports for NORMAL or documented deviations.
- Auth anomaly: check auth report for token/signature evidence.

## 9. LLM Output Quality Checklist

- riskLevel preserved: inspect each 08-dashscope-report-*.json.
- evidenceRefs present: inspect recommendations and evidenceUsage in each DashScope report.
- validation errors: see 10-validation-summary.json and per-report validation fields.
- simulation boundary: DashScope output must say this is development simulation, not production incident.
- unsupported alert fabrication: validator should catch HIGH_5XX / AUTH_FAILURE_SPIKE without evidence.
- Gateway local limiter fabrication: output should not claim Gateway local rate limiter fired unless evidence says so.

## 10. Failures And Gaps

- API request errors: $(@($script:ApiErrors).Count), see 11-raw-api-errors.jsonl.
- DashScope fallback count: $dashFallback.
- Reports with insufficient evidence should be inspected in per-report JSON.
- If expected alerts are missing, tune phase C traffic weights or alert evaluator windows.

## 11. Recommendations

- Add LLM Eval Cases from this run's best and worst DashScope outputs.
- Add a frontend or HTML summary over these JSON artifacts.
- Consider a dedicated overlap scenario runner if repeated manual runs need stronger reproducibility.

Output directory: $RunDir
"@ | ForEach-Object { Write-Utf8Text -Path $FinalReviewPath -Content $_ }
}

try {
    Write-Host "Output directory: $RunDir"
    if ($SkipDashScope) {
        Write-Host "SkipDashScope enabled. DashScope env loading and LLM calls are skipped."
    }
    else {
        Load-EnvFile -Path $EnvFile
        Write-Host "Loaded DashScope config from env file. API key is not printed."
    }

    Write-TestPlan
    $healthServer = Invoke-Json -Method "GET" -Url "$BaseUrl/api/health" -TimeoutSec 10
    $healthMock = Invoke-Json -Method "GET" -Url "$MockProviderBaseUrl/mock-provider/health" -TimeoutSec 10
    Save-Json -Path (Join-Path $RunDir "health-checks.json") -Value ([ordered]@{ server = $healthServer.response; mockProvider = $healthMock.response })
    if (-not $healthServer.ok -or -not $healthMock.ok) {
        throw "health check failed. serverOk=$($healthServer.ok), mockProviderOk=$($healthMock.ok)"
    }

    $trafficStart = Get-Date
    Run-Traffic
    $trafficEnd = Get-Date
    $trafficSummary = Build-TrafficSummary
    $windows = Get-WindowSpecs -Start $trafficStart
    Invoke-StatsAggregate -Windows $windows
    Invoke-AlertEvaluate -Windows $windows
    Invoke-AgentDiagnose -Windows $windows
    if ($SkipDashScope) {
        Write-Host "DashScope diagnosis skipped by -SkipDashScope."
    }
    else {
        Invoke-DashScopeDiagnosis
    }
    Write-FinalReview -TrafficSummary $trafficSummary -Windows $windows

    Write-Host "Completed. Output directory: $RunDir" -ForegroundColor Green
    Write-Host "Final review: $FinalReviewPath" -ForegroundColor Green
}
catch {
    $errorRecord = Write-ScriptError -ErrorRecord $_ -Stage "top-level"
    try {
        $trafficSummary = Build-TrafficSummary
        $windows = Get-WindowSpecs -Start $script:RunStartedAt
        Write-FinalReview -TrafficSummary $trafficSummary -Windows $windows
    } catch {
        Write-Utf8Text -Path $FinalReviewPath -Content "Final review generation failed: $($_.Exception.Message)"
    }
    Write-Host "Failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Output directory: $RunDir"
    exit 1
}
