# API-HUB Agent 15min DashScope Business Test Design

This temporary design file belongs to `D:\tmp\apihub-agent-dashscope-15min-business-test` and is not part of the project repository.

## Purpose

Generate an end-to-end business demonstration around:

- daily baseline traffic
- lecture registration ramp-up
- lecture registration peak
- network/downstream fluctuation overlap
- ramp-down and recovery
- light authentication anomaly
- deterministic Agent Diagnosis
- DashScope structured LLM Diagnosis

## Runtime

- Default duration: 900 seconds.
- Maximum accepted duration: 1200 seconds.
- FastMode duration: 240 seconds.
- DebugMode duration: 90 seconds by default, configurable with `-DebugDurationSeconds`.
- Mode priority: `DebugMode > FastMode > DurationSeconds`.
- `-DurationSeconds 120` is preserved unless `-DebugMode` or `-FastMode` is also provided.

## Phase Plan

All durations are scaled proportionally for 900s, 240s, 90s, or another accepted duration.

| Phase | Business Label | Slug | Base Duration | Expected Risk |
|---|---|---|---:|---|
| Phase A | 日常低峰基线 | daily-baseline | 150s | NORMAL |
| Phase B | 讲座报名爬坡 | lecture-ramp-up | 150s | RISING |
| Phase C | 讲座报名高峰 + 网络波动交叉 | lecture-peak-network-overlap | 330s | WARNING |
| Phase D | 讲座报名回落 + 网络恢复 | lecture-ramp-down-network-recovery | 120s | RECOVERING |
| Phase E | 轻量认证异常穿插 | light-auth-anomaly | 90s | LOCAL_AUTH_EVIDENCE |
| Phase F | 恢复日常基线 | recovered-daily-baseline | 60s | NORMAL |

Every traffic sample records `phaseCode`, `phaseSlug`, `phaseName`, and `scenarioName`.

## Script

```powershell
powershell -ExecutionPolicy Bypass -File D:\tmp\apihub-agent-dashscope-15min-business-test\run-dashscope-15min-business-test.ps1 -IncludePrompt
```

Fast debug run:

```powershell
powershell -ExecutionPolicy Bypass -File D:\tmp\apihub-agent-dashscope-15min-business-test\run-dashscope-15min-business-test.ps1 -FastMode -IncludePrompt
```

Short local debug run without DashScope:

```powershell
powershell -ExecutionPolicy Bypass -File D:\tmp\apihub-agent-dashscope-15min-business-test\run-dashscope-15min-business-test.ps1 -DebugMode -SkipDashScope
```

Fast local run without DashScope:

```powershell
powershell -ExecutionPolicy Bypass -File D:\tmp\apihub-agent-dashscope-15min-business-test\run-dashscope-15min-business-test.ps1 -FastMode -SkipDashScope
```

## Artifacts

Each run writes to:

```text
D:\tmp\apihub-agent-dashscope-15min-business-test\output\run-<yyyyMMdd-HHmmss>
```

Expected files:

- `00-test-plan.json`
- `01-business-timeline.md`
- `02-traffic-samples.jsonl`
- `03-traffic-summary.json`
- `04-stats-aggregator-responses.json`
- `05-alert-evaluator-responses.json`
- `06-agent-diagnosis-report-index.json`
- `07-deterministic-report-<reportName>.json`
- `08-dashscope-report-<reportName>.json`
- `09-prompt-<reportName>.json`
- `10-validation-summary.json`
- `11-raw-api-errors.jsonl`
- `17-final-review.md`
- `99-script-error.json` when the script itself fails before normal completion.

## Safety

- The script reads `docker\.env` into process environment only.
- It does not print or persist `DASHSCOPE_API_KEY`.
- It sends traffic through `POST /api/dev/gateway/invoke`.
- It does not directly write database rows.
- It does not modify project code, project docs, project scripts, or git state.
- It does not stop or restart 8080 / 8090.
- `-SkipDashScope` avoids reading DashScope configuration and avoids LLM calls.
- `-SkipPromptSave` avoids persisting full prompts.
