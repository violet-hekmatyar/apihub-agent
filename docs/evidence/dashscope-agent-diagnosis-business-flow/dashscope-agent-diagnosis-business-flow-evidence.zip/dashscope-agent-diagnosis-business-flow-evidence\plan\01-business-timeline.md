# API-HUB Agent 15min DashScope Business Test Timeline

RunId: manual_dashscope_15min_20260623-151937
DurationSeconds: 900

| Phase | Relative Time | Slug | Business Meaning | Expected Risk |
|---|---|---|---|---|
| Phase A: 日常低峰基线 | 00:00-02:30 | daily-baseline | Daily low-traffic baseline. | NORMAL |
| Phase B: 讲座报名爬坡 | 02:30-05:00 | lecture-ramp-up | Lecture signup traffic ramps up before opening. | RISING |
| Phase C: 讲座报名高峰 + 网络波动交叉 | 05:00-10:30 | lecture-peak-network-overlap | Lecture signup peak overlaps with network/downstream fluctuation. | WARNING |
| Phase D: 讲座报名回落 + 网络恢复 | 10:30-12:30 | lecture-ramp-down-network-recovery | Lecture peak and network fluctuation taper down. | RECOVERING |
| Phase E: 轻量认证异常穿插 | 12:30-14:00 | light-auth-anomaly | Light authentication anomaly is injected for local evidence. | LOCAL_AUTH_EVIDENCE |
| Phase F: 恢复日常基线 | 14:00-15:00 | recovered-daily-baseline | Traffic returns to a daily baseline. | NORMAL |

All traffic is sent through POST /api/dev/gateway/invoke. No database writes are performed directly by this script.